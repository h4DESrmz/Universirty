package StudentMgmtSys;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;

import org.junit.jupiter.api.Test;

class dbConnectionTest {

	@Test
	void test() {
		Connection con;
		con = dbconnect.java_db();
		assertEquals(con,);
	}

}
